Welcome to Battleship!

Please tell me of any bugs you encounter or other things that may not be quite right!

Keep in mind this is a project for a class, and not a AAA title.

About ship_placement.csv:
	You may change the layout of your ships in this file. However, I recommend leaving them as they are. If you do wish to change it, make sure to open the file as a word document, not in Excel. However, changing the values may result in undefined behavior. I cannot guarantee the game will run correctly if you change them.
	
Over 1300 lines of code and close to 20 hours of work went into this, hope you enjoy.	

Thanks for playing. :)

- Chase Williamson